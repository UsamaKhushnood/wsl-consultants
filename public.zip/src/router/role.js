export const role = {
  Admin: "admin",
  Call: "call",
  Sale: "sale",
};
