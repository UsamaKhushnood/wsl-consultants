<template>
  <div id="new-request-all-popups">
    <AssignLeadPopup :propsindex="propsindex" />
    <HoldRequestPopup :propsindex="propsindex" />
    <DenyRequestPopup :propsindex="propsindex" />
    <ViewShopSidebar :propsindex="propsindex" />
    <ViewDetailsSidebar :propsindex="propsindex" />
    <AddNotePopup :propsindex="propsindex" />
    <EditLead :propsindex="propsindex" :items="items" />
  </div>
</template>
<script>
import ViewShopSidebar from "./popups/ViewShopSidebar.vue";
import HoldRequestPopup from "./popups/HoldRequestPopup.vue";
import DenyRequestPopup from "./popups/DenyRequestPopup.vue";
import AssignLeadPopup from "./popups/AssignLeadPopup.vue";
import ViewDetailsSidebar from "./popups/ViewDetailsSidebar.vue";
import AddNotePopup from "./popups/AddNotePopup.vue";
import EditLead from "./popups/EditLead.vue";
export default {
  components: {
    AssignLeadPopup,
    DenyRequestPopup,
    HoldRequestPopup,
    ViewShopSidebar,
    ViewDetailsSidebar,
    AddNotePopup,
    EditLead,
  },
  name: "AllPopups",
  props: ["propsindex","items"],
};
</script>
<style lang="scss"></style>
